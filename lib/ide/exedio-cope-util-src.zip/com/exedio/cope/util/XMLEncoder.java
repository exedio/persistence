/*
 * Copyright (C) 2004-2015  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.util;

public final class XMLEncoder
{
	private XMLEncoder()
	{
		// forbid instantiation
	}

	public static String encode(final String st)
	{
		if(st==null)
			return null;

		StringBuilder sb = null;
		final int length = st.length();
		int lastPos = 0;
		for(int pos = 0; pos<length; pos++)
		{
			final char c = st.charAt(pos);
			final String replacement;
			switch(c)
			{
				case '&'  -> replacement = "&amp;";
				case '<'  -> replacement = "&lt;";
				case '>'  -> replacement = "&gt;";
				case '"'  -> replacement = "&quot;";
				case '\'' -> replacement = "&apos;";
				default ->
					{ continue; }
			}
			if(sb==null)
				sb = new StringBuilder();
			if(lastPos<pos)
				sb.append(st, lastPos, pos);
			sb.append(replacement);
			lastPos = pos + 1;
		}
		if(sb==null)
			return st;
		if(lastPos<length)
			sb.append(st, lastPos, length);
		return sb.toString();
	}

	public static void append(final StringBuilder sb, final String st)
	{
		final int length = st.length();
		int lastPos = 0;
		for(int pos = 0; pos<length; pos++)
		{
			final char c = st.charAt(pos);
			final String replacement;
			switch(c)
			{
				case '&'  -> replacement = "&amp;";
				case '<'  -> replacement = "&lt;";
				case '>'  -> replacement = "&gt;";
				case '"'  -> replacement = "&quot;";
				case '\'' -> replacement = "&apos;";
				default ->
					{ continue; }
			}
			if(lastPos<pos)
				sb.append(st, lastPos, pos);
			sb.append(replacement);
			lastPos = pos + 1;
		}
		if(lastPos<length)
			sb.append(st, lastPos, length);
	}

	public static void append(final StringBuilder sb, final char c)
	{
		final String replacement;
		switch(c)
		{
			case '&'  -> replacement = "&amp;";
			case '<'  -> replacement = "&lt;";
			case '>'  -> replacement = "&gt;";
			case '"'  -> replacement = "&quot;";
			case '\'' -> replacement = "&apos;";
			default -> {
				sb.append(c);
				return;
			}
		}
		sb.append(replacement);
	}
}
