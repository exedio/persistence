/*
 * Copyright (C) 2004-2015  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.util;

import java.nio.charset.StandardCharsets;

public final class CharsetName
{
	/**
	 * See <a href="https://www.iana.org/assignments/character-sets">IANA</a>.
	 * @deprecated Use {@link StandardCharsets#UTF_8} instead
	 */
	@Deprecated
	public static final String UTF8 = "UTF-8";

	private CharsetName()
	{
		// prevent instantiation
	}
}
