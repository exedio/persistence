
package javax.annotation;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.SOURCE;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Provides an annotation deprecated in jdk9 and removed in jdk11.
 * See <a href="https://docs.oracle.com/javase/9/docs/api/javax/annotation/Generated.html">API doc</a>.
 */

@Documented
@Retention(SOURCE)
@Target({TYPE, METHOD, CONSTRUCTOR, FIELD})
public @interface Generated
{
	String[] value();
}
