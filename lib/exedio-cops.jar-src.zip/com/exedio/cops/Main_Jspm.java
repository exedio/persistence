
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cops;

import java.io.PrintStream;
import java.util.Iterator;

final class Main_Jspm
{
	public static final void write(final PrintStream out, final RadioField field)
	{
		for(Iterator<?> i = field.names.iterator(); i.hasNext(); )
		{
			final String optionValue = (String)i.next();
			out.print("\n" +
	"\t\t\t<input type=\"radio\" name=\"");
out.print(field.name);
out.print("\" value=\"");
out.print(optionValue);
out.print("\"");

			final String style = field.style;
			if(style!=null)
			{
				out.print(" style=\"");
out.print(style);
out.print("\"");

			}
			if(field.isChecked(optionValue))
			{
				out.print(" checked=\"checked\"");

			}
			out.print(">");
out.print(field.getValue(optionValue));
out.print("<br>");

		}
	}
	
	public static final void write(final PrintStream out, final DropdownField field)
	{
		out.print("\n" +
	"\t\t<select name=\"");
out.print(field.name);
out.print("\"");

		final String style = field.style;
		if(style!=null)
		{
			out.print(" style=\"");
out.print(style);
out.print("\"");

		}
		out.print(">");

		for(Iterator<?> i = field.names.iterator(); i.hasNext(); )
		{
			final String optionValue = (String)i.next();
			out.print("\n" +
	"\t\t\t<option value=\"");
out.print(optionValue);
out.print("\"");

			if(field.isChecked(optionValue))
			{
				out.print(" selected=\"selected\"");

			}
			out.print(">");
out.print(field.getValue(optionValue));
out.print("</option>");

		}
		out.print("\n" +
	"\t\t</select>");

	}
	
	public static final void write(final PrintStream out, final CheckboxField field)
	{
		out.print("\n" +
	"\t\t<input type=\"checkbox\" name=\"");
out.print(field.name);
out.print("\" value=\"");
out.print(CheckboxField.VALUE_ON);
out.print("\"");

		final String style = field.style;
		if(style!=null)
		{
			out.print(" style=\"");
out.print(style);
out.print("\"");

		}
		if(field.content)
		{
			out.print(" checked=\"checked\"");

		}
		out.print("><br>");

	}
	
	public static final void write(final PrintStream out, final TextField field)
	{
		final String value = field.getValue();
		out.print("<input type=\"");

		if(field.password)
		{
			out.print("password");

		}
		else
		{
			out.print("text");

		}
		out.print("\" name=\"");
out.print(field.name);
out.print("\" size=\"");
out.print(field.size);
out.print("\" value=\"");
out.print(value);
out.print("\"");

		final String style = field.style;
		if(style!=null)
		{
			out.print(" style=\"");
out.print(style);
out.print("\"");

		}
		out.print(" />");

		final String error = field.getError();
		if(error!=null)
		{
			out.print(" <b>");
out.print(error);
out.print("</b>");

		}
	}
	
	public static final void writeHiddenFields(final PrintStream out, final Form form)
	{
		for(Iterator<?> i = form.getFields().iterator(); i.hasNext(); )
		{
			final Field field = (Field)i.next();
			if(!field.isWritten())
			{
				final String value = field.value;
				if(value!=null)
				{
				out.print("\n" +
	"\t\t\t\t<input type=\"hidden\" name=\"");
out.print(field.name);
out.print("\" value=\"");
out.print(value);
out.print("\" />");

				}
			}
		}
	}
}
