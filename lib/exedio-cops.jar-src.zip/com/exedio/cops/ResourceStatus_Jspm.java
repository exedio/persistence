
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cops;

import static com.exedio.cops.XMLEncoder.encode;

import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

final class ResourceStatus_Jspm
{
	public static final void write(
				final PrintStream out,
				final String servletName,
				final Collection<Resource> resources,
				final String authentication,
				final boolean inline,
				final DecimalFormat nf,
				final SimpleDateFormat dateFormat,
				final SimpleDateFormat footerDateFormat,
				final Package thePackage)
	{
out.print("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"  \"http://www.w3.org/TR/html4/loose.dtd\">\n" +
	"<html>\n" +
	"\t<head>\n" +
	"\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=");
out.print(CopsServlet.ENCODING);
out.print("\">\n" +
	"\t\t<title>Cops Servlet &quot;");
out.print(servletName);
out.print("&quot; - Resource Status</title>\n" +
	"\t\t<style>\n" +
	"\t\t\th1\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-family:sans-serif;\n" +
	"\t\t\t\tfont-size:180%;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv.authenticated\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-size:70%;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv.notauthenticated\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-size:70%;\n" +
	"\t\t\t\tcolor:#e00;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable caption\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-style:italic;\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t\twhite-space:nowrap;\n" +
	"\t\t\t\tbackground:#ccc;\n" +
	"\t\t\t\tpadding:1px 5px;\n" +
	"\t\t\t\tborder:solid 2px white;\n" +
	"\t\t\t\tborder-bottom-width:0px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable th\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t\tvertical-align:top;\n" +
	"\t\t\t\tbackground:#ccc;\n" +
	"\t\t\t\tborder:solid 1px #ccc;\n" +
	"\t\t\t\tpadding:1px 3px;\n" +
	"\t\t\t\tfont-weight:normal;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable td\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:right;\n" +
	"\t\t\t\tvertical-align:top;\n" +
	"\t\t\t\tborder:solid 1px #ccc;\n" +
	"\t\t\t\tpadding:1px 3px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable td.text\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg\n" +
	"\t\t\t{\n" +
	"\t\t\t\tborder:0;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg.logo\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfloat:right;\n" +
	"\t\t\t\twidth:198px;\n" +
	"\t\t\t\theight:60px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv.footer\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-size:70%;\n" +
	"\t\t\t}\n" +
	"\t\t</style>\n" +
	"\t</head>\n" +
	"\t<body>\n" +
	"\t\t<a href=\"http://cope.sourceforge.net/\" target=\"_blank\"><img src=\"http://cope.sourceforge.net/exedio.png\" alt=\"Exedio Logo\" class=\"logo\"></a>\n" +
	"\t\t<h1>Cops Servlet &quot;");
out.print(servletName);
out.print("&quot;</h1>\n" +
	"\t\t<div class=\"");
 if(authentication==null){out.print("not");
} out.print("authenticated\">");

			if(authentication!=null)
			{
				out.print("authenticated as ");
out.print(encode(authentication));

			}
			else
			{
				out.print("not authenticated");

			}
		out.print("</div>\n" +
	"\t\t<table>\n" +
	"\t\t\t<caption>Resource Status</caption>\n" +
	"\t\t\t<tr>\n" +
	"\t\t\t\t<th>304</th>\n" +
	"\t\t\t\t<th>200</th>\n" +
	"\t\t\t\t<th>Length</th>\n" +
	"\t\t\t\t<th>304l</th>\n" +
	"\t\t\t\t<th>200l</th>\n" +
	"\t\t\t\t<th><a href=\"copsResourceStatus.html");

						if(!inline){ out.print("?");
out.print(CopsServlet.INLINE);
out.print("=t");
 } out.print("\">");

						if(inline){ out.print("Image");
 }else{ out.print("i");
 }
					out.print("</a></th>\n" +
	"\t\t\t\t<th>Name</th>\n" +
	"\t\t\t\t<th>Content Type</th>\n" +
	"\t\t\t\t<th>Last Modified</th>\n" +
	"\t\t\t</tr>");

			
			long response304CountTotal = 0;
			long response200CountTotal = 0;
			long contentLengthTotal = 0;
			long response304LengthTotal = 0;
			long response200LengthTotal = 0;
			
			for(final Resource resource : resources)
			{
				final long response304Count = resource.getResponse304Count();
				final long response200Count = resource.getResponse200Count();
				final int contentLength = resource.getContentLength();
				final long response304Length = response304Count * contentLength;
				final long response200Length = response200Count * contentLength;
				final String contentType = resource.getContentType();
				final boolean inlineThis = inline && contentType.startsWith("image/");
			out.print("\n" +
	"\t\t\t<tr>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response304Count));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response200Count));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(contentLength));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response304Length));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response200Length));
out.print("</td>\n" +
	"\t\t\t\t<td class=\"text\">");
 if(inlineThis){out.print("<img src=\"");
out.print(resource);
out.print("\">");
} out.print("</td>\n" +
	"\t\t\t\t<td class=\"text\"><a href=\"");
out.print(resource);
out.print("\">");
out.print(encode(resource.getName()));
out.print("</a></td>\n" +
	"\t\t\t\t<td class=\"text\">");
out.print(encode(contentType));
out.print("</td>\n" +
	"\t\t\t\t<td class=\"text\">");
out.print(dateFormat.format(resource.getLastModified()));
out.print("</td>\n" +
	"\t\t\t</tr>");

			
				response304CountTotal += response304Count;
				response200CountTotal += response200Count;
				contentLengthTotal += contentLength;
				response304LengthTotal += response304Length;
				response200LengthTotal += response200Length;
			}
		out.print("\n" +
	"\t\t\t<tr>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response304CountTotal));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response200CountTotal));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(contentLengthTotal));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response304LengthTotal));
out.print("</td>\n" +
	"\t\t\t\t<td>");
out.print(nf.format(response200LengthTotal));
out.print("</td>\n" +
	"\t\t\t\t<th colspan=\"4\">Total</th>\n" +
	"\t\t\t</tr>\n" +
	"\t\t</table>\n" +
	"\t\t<div class=\"footer\">\n" +
	"\t\t\t");
out.print(encode(thePackage.getSpecificationTitle()));
out.print("\n" +
	"\t\t\t");
out.print(encode(thePackage.getSpecificationVersion()));
out.print("\n" +
	"\t\t\t");
out.print(footerDateFormat.format(new Date()));
out.print("\n" +
	"\t\t</div>\n" +
	"\t</body>\n" +
	"</html>\n" +
	"");

	}
}
