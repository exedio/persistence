
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cops;

import java.io.PrintStream;

final class RequestLimiter_Jspm
{
	static final void write(
			final PrintStream out,
			final String path,
			final int threshold,
			final int interval,
			final long deniedRequests)
	{
out.print("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"  \"http://www.w3.org/TR/html4/loose.dtd\">\n" +
	"<html>\n" +
	"\t<head>\n" +
	"\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=");
out.print(CopsServlet.UTF8);
out.print("\">\n" +
	"\t\t<title>Request Limiter</title>\n" +
	"\t</head>\n" +
	"\t<body>\n" +
	"\t\t<h1>Request Limiter</h1>\n" +
	"\t\tDenied requests: ");
out.print(deniedRequests);
out.print("\n" +
	"\t\t<br>\n" +
	"\t\tSet new threshold:\n" +
	"\t\t<form action=\"");
out.print(path);
out.print("\" method=\"POST\">\n" +
	"\t\t\t<input type=\"text\"   value=\"");
out.print(threshold);
out.print("\" name=\"");
out.print(RequestLimiter.THRESHOLD);
out.print("\" />\n" +
	"\t\t\t<input type=\"submit\" value=\"set\" />\n" +
	"\t\t</form>\n" +
	"\t\t<br>\n" +
	"\t\tSet new interval:\n" +
	"\t\t<form action=\"");
out.print(path);
out.print("\" method=\"POST\">\n" +
	"\t\t\t<input type=\"text\"   value=\"");
out.print(interval);
out.print("\" name=\"");
out.print(RequestLimiter.INTERVAL);
out.print("\" />\n" +
	"\t\t\t<input type=\"submit\" value=\"set\" />\n" +
	"\t\t</form>\n" +
	"\t</body>\n" +
	"</html>");

	}
}
