
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cops;

import java.io.PrintStream;
import java.util.Arrays;

final class ColoredTable_Jspm
{
	private ColoredTable_Jspm()
	{
		// prevent instantiation
	}
	
	private static final int COLORS = 2;
	
	static final void writeHeader(final PrintStream out, final String[] names, final String[] shortNames)
	{
			if(names.length<=shortNames.length)
				throw new RuntimeException(Arrays.toString(names) + Arrays.toString(shortNames));
			
			out.print("\n" +
	"\t\t\t<tr style=\"display:none;\">\n" +
	"\t\t\t\t<th colspan=\"");
out.print( names.length );
out.print("\" class=\"color0\">");
out.print(names[0]);
out.print("</th>\n" +
	"\t\t\t</tr>");

	
			for(int i = 1; i<shortNames.length; i++)
			{
			out.print("\n" +
	"\t\t\t<tr style=\"display:none;\">\n" +
	"\t\t\t\t<th rowspan=\"");
out.print( shortNames.length - i );
out.print("\" class=\"color");
out.print( (i-1)%COLORS );
out.print("\"></th>\n" +
	"\t\t\t\t<th colspan=\"");
out.print(      names.length - i );
out.print("\" class=\"color");
out.print( i%COLORS );
out.print("\">");
out.print(names[i]);
out.print("</th>\n" +
	"\t\t\t</tr>");

			}
			out.print("\n" +
	"\t\t\t<script>\n" +
	"\t\t\t\tfunction displayColored()\n" +
	"\t\t\t\t{\n" +
	"\t\t\t\t\tvar table = document.getElementById(\"coloredTable\");\n" +
	"\t\t\t\t\tvar rows=table.rows;\n" +
	"\t\t\t\t\tfor(rowCount=0; rowCount<rows.length; rowCount++)\n" +
	"\t\t\t\t\t{\n" +
	"\t\t\t\t\t\tvar row=rows[rowCount];\n" +
	"\t\t\t\t\t\tif(row.style.display==\"none\")\n" +
	"\t\t\t\t\t\t\trow.style.display = \"table-row\";\n" +
	"\t\t\t\t\t}\n" +
	"\t\t\t\t\treturn true;\n" +
	"\t\t\t\t}\n" +
	"\t\t\t</script>\n" +
	"\t\t\t<tr>");

			int i = 0;
			for(; i<shortNames.length; i++)
			{
				out.print("\n" +
	"\t\t\t\t<th class=\"color");
out.print( i%COLORS );
out.print("s\" title=\"");
out.print(names[i]);
out.print("\">");
out.print(
					shortNames[i] );

					if(i==0)
					{
						out.print("<span class=\"help\" onClick=\"return displayColored();\">?</span>");

					}
					out.print("</th>");

			}
			for(; i<names.length; i++)
			{
				out.print("\n" +
	"\t\t\t\t<th>");
out.print( names[i] );
out.print("</th>");

			}
			out.print("\n" +
	"\t\t\t</tr>");

	}
	
	static final void writeData(final PrintStream out, final String[] data)
	{
			for(int i = 0; i<data.length; i++)
			{
			out.print("\n" +
	"\t\t\t\t<td class=\"color");
out.print( i%COLORS );
out.print("\">");
out.print(data[i]);
out.print("</td>");

			}
	}
}